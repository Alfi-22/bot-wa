function handler(m) {
  this.sendContact(m.chat, '6283839014199', this.getName('6283839014199@s.whatsapp.net'), m)
}
handler.help = ['owner', 'creator']
handler.tags = ['info']

handler.command = /^(owner|creator)$/i

module.exports = handler
